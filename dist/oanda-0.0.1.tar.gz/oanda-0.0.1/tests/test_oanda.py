from oanda import Client

def test_oanda():
    fx = Client()
    fx.set_base_url("https://api-fxpractice.oanda.com")
    assert fx.base_url == "https://api-fxpractice.oanda.com"