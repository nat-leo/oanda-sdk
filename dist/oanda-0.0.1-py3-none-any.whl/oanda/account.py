from oanda.oanda import Client

class Account(Client):
    pass