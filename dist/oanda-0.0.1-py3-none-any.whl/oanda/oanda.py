class Client:
    def __init__(self, base_url="", account_number="", api_token=""):
        self.base_url = base_url
        self.account_number = account_number
        self.api_token = api_token

    def set_base_url(self, base_url: str) -> None:
        self.base_url = base_url

    def set_account_number(self, account_number: str) -> None:
        self.account_number = account_number
    
    def set_api_token(self, api_token: str) -> None:
        self.api_token = api_token