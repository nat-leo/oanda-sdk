# Oanda-SDK

A wrapper for the Oanda REST API.

```
pip install oanda-sdk
```

## Welcome to Oanda-SDK!

Check out [getting started](getting-started.md) for a walkthrough.

## API Reference

The [API Reference](api/overview.md)